import  React, {useState}  from 'react';
import ReactDOM from 'react-dom/client';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Col, Row, Form } from 'react-bootstrap';
import validator from 'validator';
//import Axios from "axios";\
import axios from "axios"
import { Formik } from "formik";
import * as Yup from "yup";
import { Alert } from "react-bootstrap";
import { response } from 'express';


function SignupForm() {
    /* const [first_name, setFirstname] = useState("");
    const [last_name, setLastname] = useState("");
    const [email, setEmail] = useState("");
    const [username, setUsername] = useState("");
    const [phone_no, setPhoneno] = useState("");
    const [password, setPassword] = useState("");
    const [registerStatus, setRegisterStatus] = useState("");

    const register = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8080/auth/signups",
            {
                first_name: first_name,
                last_name: last_name,
                email: email,
                username: username,
                phone_no: phone_no,
                password: password
            }).then((response) => {
                if (response.data.message) {
                    setRegisterStatus(response.data.message);
                }
                else {
                    setRegisterStatus("ACCOUNT CREATED SUCCESSFULLY");
                }
            });

    }

return(
    <>

    <div  className="SignupForm">
        <form>
            <h4>Register Here</h4>
            <label htmlFor='first_name'>Firstname</label>
            <input type="text" name='first_name' onChange={(e)=>{setFirstname(e.target.value)}} placeholder='Firstname' required />
            <label htmlFor='last_name'>Lastname</label>
            <input type="text" name='last_name' onChange={(e)=>{setLastname(e.target.value)}} placeholder='Lastname' required />
            <label htmlFor='email'>Email</label>
            <input type="email" name='email' onChange={(e)=>{setEmail(e.target.value)}} placeholder='Email' required />
            <label htmlFor='username'>Username</label>
            <input type="username" name='username' onChange={(e)=>{setUsername(e.target.value)}} placeholder='Username' required />
            <label htmlFor='phone_no'>Phone no</label>
            <input type="tel" pattern="[6-9]{1}[0-9]{8}" name='phone_no' onChange={(e)=>{setPhoneno(e.target.value)}} placeholder='Phone no' required />
            <label htmlFor='password'>Password</label>
            <input type="password" name='password' onChange={(e)=>{setPassword(e.target.value)}} placeholder='Password' required />
            <input type='submit' onClick={register} value="Create an Account"/>
            <h1 style={{fontSize:'15px', textAlign:'center',marginTop:'20px'}}>{registerStatus}</h1>
        </form>
    </div>
   
    </>
) */
   const [values, setValues] = useState({
        first_name: '',
        last_name: '',
        email: '',
        username: '',
        phone_no: '',
        password: ''
    })
    //const [errors] =useState({});
    const handleChange = (event) => {
        setValues(prev =>({ ...prev, [event.target.name]: [event.target.value] }))
    }
    const handleSubmit = (event) => {
        event.preventDefault();
        //setErrors(Validation(values));
       // if(first_name===""&& last_name==="" &&username ==="" && email ===""&& phone_no ==="" && password ==="" )
        if(true){
        axios.post('http://localhost:8080/auth/signups', { values })
            .then(res => console.log("Registered Successfully ..."))
            .catch(err => console.log(err));
    }
}
    
    
    return (
    
        <div className='d-flex justify-content-center align-items-center bg-primary vh-100'>
            <div className='bg-white p-3 rounded w-25'>
                <form onSubmit={handleSubmit} >
                
                    <div className="mb-3">
                        <label htmlFor='first_name'  >First Name </label>
                        <input className="form-control rounded-0" type="text" required name='first_name' onChange={handleChange} placeholder="First Name" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor='last_name' >Last Name </label>
                        <input className="form-control rounded-0" type="text" required name='last_name' onChange={handleChange} placeholder="LastName" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor='email' >Email </label>
                        <input type="email" className="form-control rounded-0" required name='email' onChange={handleChange} placeholder="Email" />
                        
                    </div>

                    <div className="mb-3">
                        <label htmlFor='username' >Username</label>
                        <input type="text" className="form-control rounded-0" required name='username' onChange={handleChange} placeholder="Username" />
                    </div>

                    <div className="mb-3">
                        <label htmlFor='phone_no' >Phone_no </label>
                        <input type="tel" pattern="[6-9]{1}[0-9]{8}" required className="form-control rounded-0" name='phone_no' onChange={handleChange} placeholder="phone_no" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor='password' for="password">Password </label>
                        <input type="password" className="form-control rounded-0" required name='password' onChange={handleChange} placeholder="Password" />
                    </div>
                    <button type='submit'>Signup</button>
                    <a to='/'></a>

                </form>
            </div>
        </div>

    );

}

/* const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<SignupForm />); */
export default SignupForm;