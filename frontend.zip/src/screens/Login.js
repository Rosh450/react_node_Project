
import React from 'react'
import { Link } from "react-router-dom"
import { Container, Row, Col } from 'react-bootstrap'
import LoginForm from "../components/auth/LoginForm";

const Login = () => {
    return (
        <>

            <div>
                <Link to="/">Home </Link>
            </div>

            <Container>
                <Row className="justify-content-center">
                    <Col md="6">
                        <LoginForm />
                    </Col>
                </Row>
            </Container>

        </>
    );
};


export default Login;

/* import React from 'react'

function Login() {
    return (
        <div>
            <h1>This is the Login page</h1>
        </div>
    )
}

 */