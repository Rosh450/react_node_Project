
import Layout from "./Layout";
import "../assets/sass/App.scss";
const Home = () => {
  return( 
    <>
  <Layout/>
  <h1>Welcome to Home Page</h1>
  </>
  );
};

export default Home;
 {/* 


import { Link } from "react-router-dom";
import {Navbar,Nav,NavLink,Container,Col,Row,Modal,Form,Button} from "react-bootstrap";
import Layout from './Layout';

function Home() {
  const [show, setShow] = useState(false);

      const handleClose = () => setShow(false);
      const handleShow = () => setShow(true);
    return (
      
      <div className='home'>
        
<Container>
<Row>
  <Col>
  <Layout/>
       <Navbar bg="dark" expand="lg">
       
        <Nav className="me-auto">
        <NavLink><Link to="/">Home </Link></NavLink>
        <NavLink><Link to="/about">About </Link></NavLink>
      <NavLink><Link to="/contact">Contact</Link></NavLink>
      <NavLink><Link to="/signup">Signup</Link></NavLink>
      <NavLink><Link to="/blog">Blog</Link><br></br></NavLink>
      <NavLink><Link to="/login">Login</Link><br></br></NavLink>
     </Nav>
    
      </Navbar> 
      </Col>
      
     

      </Container>
     
      
      <h1>This is the home page</h1><hr></hr>
      </div>
    );
  } */}
  
