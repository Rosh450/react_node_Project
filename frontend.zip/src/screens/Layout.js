import {  Link } from "react-router-dom";
import { Navbar, Nav, NavLink, Container } from "react-bootstrap";
import { Component } from "react";
import { connect } from "react-redux";
import {logoutUser} from "../actions/auth.actions";
class Layout extends Component {

    constructor(props) {
        super(props);
        this.state = {};
        this.logout = this.logout.bind(this);
    }

    logout() {
        this.props.dispatch(logoutUser());
    }

    render() {

        const { isLoggedIn } = this.props.getUser;
        return (
            <>
                <Navbar bg="dark" variant="primary">
                    <Container >
                        
                        <Nav className="me-auto">
                            <NavLink><Link to="/">Home </Link></NavLink>
                            <NavLink><Link to="/about">About </Link></NavLink>
                            <NavLink><Link to="/contact">Contact</Link></NavLink>
                           
                            <NavLink><Link to="/blog">Blog</Link><br></br></NavLink>
                            
                        </Nav>

                        <Nav className="right">
                            {!isLoggedIn &&
                                <>
                                <NavLink><Link to="/login">Login</Link><br></br></NavLink>
                                <NavLink><Link to="/signup">Signup</Link></NavLink> 
                                   
                                </>
                            }
                            {isLoggedIn &&
                                <>
                                    <Link style={{ color: "rgb(79 255 84)", fontWeight: "bold" }} to="/" onClick={() => this.logout()} >Logout</Link>
                                </>
                            }

                        </Nav>
                    </Container>
                </Navbar>
                {this.props.children}

                
            </>
        )
    }
};



const mapStateToProps = (state) => ({
    loginUser: state.authReducer.loginUser,
    getUser: state.userReducer.getUser,
});

const mapDispatchToProps = (dispatch) => ({
    dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(Layout);