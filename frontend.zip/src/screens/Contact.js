
import React from 'react'
import { Routes, Route } from "react-router-dom"
import Layout from './Layout';
const Contact = () => {
    return (
        <>
        <div >
         <Routes>
         <Route path="/" element={ <Layout/> } />
         </Routes>
         
     </div> 
    
 
         <div>
             <h1>This is the Contact page</h1>
         </div>
         </>
    )
  };
  
  export default Contact;