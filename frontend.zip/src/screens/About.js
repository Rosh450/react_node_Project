
    import React from 'react'
    import { Routes, Route } from "react-router-dom"
    import Layout from './Layout';
    
    const About = () => {
        return (
        <>
          <div >
             <Routes>
             <Route path="/" element={ <Layout/> } />
             </Routes>
             
         </div> 
        
        <h1>About Us</h1>
        </>
        )
      };
  export default About;