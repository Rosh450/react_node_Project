import React from 'react'
import { Routes, Route,Link } from "react-router-dom"
import Layout from './Layout';
import SignupForm from '../components/auth/SignupForm';


const Signup = () => {
    return (
        <>
      {/*   <div >
         <Routes>
         <Route path="/" element={ <Layout/> } />
         </Routes>
         
     </div> */}
      <div>
             <Link to="/">Home </Link>
         </div> 
  
         <div>
            <SignupForm/>
             
         </div>
         </>
    )
  };
  
export default Signup;


