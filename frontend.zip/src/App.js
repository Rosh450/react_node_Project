
import React from "react";
import { Component } from "react";
import { Container} from 'react-bootstrap';
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import persist from "./config/store";
import "./assets/sass/App.scss"
import Layout from './screens/Layout';
import { BrowserRouter } from 'react-router-dom';
import { Routes, Route} from "react-router-dom"
import Home from "./screens/Home"
import About from "./screens/About"
import Contact from "./screens/Contact"
import Blog from "./screens/Blog"
import Login from "./screens/Login"
import Signup from "./screens/Signup"

const persistStore = persist();
function onBeforeLift() {
  return "";
}

class App extends Component {
  state = {};

  constructor(props) {
    super(props);
  }
  render() {

    return (
      <>

        <Provider store={persistStore.store}>
          <PersistGate
            // loading={<SplashScreen />}
            onBeforeLift={onBeforeLift}
            persistor={persistStore.persistor}
          >
            <Container>
              
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/about" element={<About />} />
                  <Route path="/contact" element={<Contact />} />
                  <Route path="/blog" element={<Blog />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/signup" element={<Signup />} />
                </Routes>

            
            </Container>
          </PersistGate>
        </Provider>



      </>
    );
  }
}

export default App

