// Services
import { fetchApi } from '../service/api';

//signup user


// Login User
export const loginUser = (values) => {
  return async (dispatch) => {
    try {
      dispatch({
        type: 'LOGIN_USER_LOADING',
      });
      const response = await fetchApi('auth/login', 'POST', values, 200, null);
      
      
      if (response.responseBody && response.responseBody.status == 1) {
        
        dispatch({
          type: 'LOGIN_USER_SUCCESS',
        });
      
        dispatch({
          type: 'GET_USER_SUCCESS',
          token: response.responseBody.token,
          // userDetails: response.responseBody.data,
          // token: response.responseBody.data.token,
        });
        return response.responseBody;
      } else {
        dispatch({
          type: 'LOGIN_USER_FAIL',
          errorDetails: response.responseBody.data.token,
        });
        
        return response.responseBody;
      }
    } catch (error) {
      dispatch({
        type: 'LOGIN_USER_FAIL',
        errorDetails: error.responseBody,
      });
      // dispatch({
      //   type: 'GET_USER_FAIL',
      //   errorDetails: error.responseBody,
      // });
      return error;
    }
  };
};

// Logout User
export const logoutUser = () => {
  // TrackPlayer.stop();
  return async (dispatch, getState) => {
    const state = getState();
    try {
      const {
        userReducer: {
          getUser: { token },
        },
      } = state;
      
      // const response = await fetchApi(
      //   'auth/logout',
      //   'POST',
      //   {},
      //   200,
      //   token,
      // );

      dispatch({
        type: 'USER_LOGGED_OUT_SUCCESS',
      });
    } catch (e) {
      console.log('logout dispatch error',e);
    }
  };
};
