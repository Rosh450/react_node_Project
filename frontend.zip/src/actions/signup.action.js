import { fetchApi } from '../service/api';

export const signupUser = (values) => {
  return async (dispatch) => {
    try {
      dispatch({
        type: 'LOGIN_USER_LOADING',
      });
      
      const response = await fetchApi('auth/signups', 'POST', values, 200, null);
      
      if (response.responseBody && response.responseBody.status == 1) {
        
        dispatch({
          type: 'SIGNUP_USER_SUCCESS',
        });
      
        dispatch({
          type: 'GET_USER_SUCCESS',
          token: response.responseBody.token,
          // userDetails: response.responseBody.data,
          // token: response.responseBody.data.token,
        });
        return response.responseBody;
      } else {
        dispatch({
          type: 'SIGNUP_USER_FAIL',
          errorDetails: response.responseBody.data.token,
        });
        
        return response.responseBody;
      }
    } catch (error) {
      dispatch({
        type: 'SIGNUP_USER_FAIL',
        errorDetails: error.responseBody,
      });
      // dispatch({
      //   type: 'GET_USER_FAIL',
      //   errorDetails: error.responseBody,
      // });
      return error;
    }
  };
};